create procedure csQuerySetSourceInfo(IN evaluationId varchar(500))
  BEGIN
	SELECT DISTINCT 
					case 
						when query_source = 'Users' then "كاربران"
						when query_source = 'Yooz' then "لاگ يوز"
						when query_source = 'Parsijoo' then "لاگ پارسي جو"
					end as x
					, count(*) as y
		FROM csQuerySet 
		WHERE evaluation_id = evaluationId 
		GROUP BY query_source;
END;

