create procedure compute_Agg_Avail_Stats(IN searchEngineName varchar(45), IN service varchar(45),
                                         IN startOfPeriod    varchar(100), IN endOfPeriod varchar(100))
  BEGIN
SELECT 	
		`am_nonfunctional_availabilityStats`.`SearchEngineName`,
		`am_nonfunctional_availabilityStats`.`Service`,
		`am_nonfunctional_availabilityStats`.`isAvailable`,
		`am_nonfunctional_availabilityStats`.`isNotAvailable`,
		`am_nonfunctional_availabilityStats`.`isInternetAvailable`,
        otherErrorsAvailable,
        otherErrorMessage,
        TestDate
        
FROM 
		`SearchEnginePortalDB2`.`am_nonfunctional_availabilityStats`
WHERE 
		`am_nonfunctional_availabilityStats`.`SearchEngineName` = searchEngineName AND
        `am_nonfunctional_availabilityStats`.`Service` = service AND
		TestDate >= CONVERT(startOfPeriod, DATETIME) AND
		TestDate <= CONVERT(endOfPeriod, DATETIME);
END;

