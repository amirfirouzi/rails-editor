create procedure getMTEvaluationResultBleuPerSentence()
  BEGIN
	SELECT
		ts.QueryType as x,
        avg(mtp.`value`) as y,
		getSearchEngineFaName(translator) as serie 
    FROM 
		am_MTEvaluationresult_persentence mtp join TranslationSentences ts on mtp.sentence_id=ts.QueryID
	WHERE 
		metric = 'Bleu' and
        ts.IsStandard=true
	GROUP BY
		mtp.translator, ts.QueryType;
END;

