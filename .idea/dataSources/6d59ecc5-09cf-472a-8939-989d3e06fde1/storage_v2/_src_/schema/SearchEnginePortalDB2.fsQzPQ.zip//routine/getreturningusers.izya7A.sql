create procedure getReturningUsers()
  BEGIN
	SELECT 
		`date`,
        `number`,
        searchEngine
    FROM 
		tempReturningUsers
	ORDER BY
		date ASC;
END;

