create procedure getServicesUnderEvaluationInfo()
  BEGIN
SELECT `amSearchEnginesUnderEvaluation`.`id`,
    `amSearchEnginesUnderEvaluation`.`SearchEngine`,
    `amSearchEnginesUnderEvaluation`.`SubSystem`,
    `amSearchEnginesUnderEvaluation`.`Status`,
    `amSearchEnginesUnderEvaluation`.`WebService`,
    `amSearchEnginesUnderEvaluation`.`URL`,
    `amSearchEnginesUnderEvaluation`.`retrieverClassName`
FROM `SearchEnginePortalDB2`.`amSearchEnginesUnderEvaluation`
WHERE `amSearchEnginesUnderEvaluation`.`Status` = 1;
END;

