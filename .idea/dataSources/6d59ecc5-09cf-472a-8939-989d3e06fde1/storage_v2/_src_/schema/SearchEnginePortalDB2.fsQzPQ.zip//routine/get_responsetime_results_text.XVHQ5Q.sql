create procedure get_ResponseTime_Results_Text()
  BEGIN
	SELECT persian_date(DATE(TestDate)) as x, 
    
    (AVG(truncate((AvarageResponseTime),6))) as 'زمان پاسخ', 
    SearchEngineName as serie #nDCG
		FROM  SearchEnginePortalDB2.am_nonFunctional_ResponseTime
		WHERE 
				Service = 'EvaluateTextSearchEngine'
                #AND
                #DATE(TestDate) >= DATE(startOfPeriod) AND
			    #DATE(TestDate) <= DATE(endOfPeriod) AND
                #queryLength =  numberofWords
		group by Date(TestDate), SearchEngineName, Service
		ORDER BY persian_date(DATE(TestDate)) asc;
        
END;

