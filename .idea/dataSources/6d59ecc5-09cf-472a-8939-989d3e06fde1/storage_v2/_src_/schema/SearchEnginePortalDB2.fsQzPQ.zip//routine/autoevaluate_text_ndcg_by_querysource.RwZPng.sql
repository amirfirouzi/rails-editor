create procedure autoEvaluate_Text_nDCG_By_QuerySource(IN evaluationDate varchar(100))
  BEGIN
	select q.querySource as x , avg(r.nDCG) as 'nDCG' , r.retriever as serie, r.date as title
		from amQuerySet q, amEvaluationResultsForEachQuery r
		where 
			q.query = r.query and 
            q.service=3 and
            r.date like concat(evaluationDate,'%')
		group by 
			r.retriever,q.querySource;

END;

