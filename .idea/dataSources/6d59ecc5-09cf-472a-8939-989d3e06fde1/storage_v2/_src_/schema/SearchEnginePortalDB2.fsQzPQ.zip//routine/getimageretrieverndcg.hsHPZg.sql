create procedure getImageRetrieverNDCG(IN minDate varchar(100), IN maxDate varchar(100))
  BEGIN
	select concat(SearchEnginePortalDB2.persian_year(ResultDate), '-', SearchEnginePortalDB2.persian_month(ResultDate), '-', SearchEnginePortalDB2.persian_day(ResultDate)) as x, criterionValue as y, retriever as serie from SearchEnginePortalDB2.amAccuracyResults 
	where service='EvaluateImageSearchEngine'
	and QueryCategory='All'
	and ResultDate > minDate
	and ResultDate < maxDate
	and criterion='NDCG' order by SearchEnginePortalDB2.persian_year(ResultDate), SearchEnginePortalDB2.persian_month(ResultDate), SearchEnginePortalDB2.persian_day(ResultDate);
END;

