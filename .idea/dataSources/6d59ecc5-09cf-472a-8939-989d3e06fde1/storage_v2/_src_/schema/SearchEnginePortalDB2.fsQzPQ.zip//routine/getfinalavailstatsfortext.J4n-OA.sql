create procedure getFinalAvailStatsforText(IN testDate varchar(200))
  BEGIN

SELECT 
		persian_date(DATE(TestDate)) as x, 
        format((SUM(`amAggregatedDataOfAvailabilities`.`SuccessCount`) /SUM(`amAggregatedDataOfAvailabilities`.`Hits`)), 2) as 'دسترس پذیری',
		SearchEngineName as serie
    
FROM `SearchEnginePortalDB2`.`amAggregatedDataOfAvailabilities`

WHERE DATE(`amAggregatedDataOfAvailabilities`.`TestDate`) = DATE(testDate) AND
			`amAggregatedDataOfAvailabilities`.`Service` = 'EvaluateTextSearchEngine'
            
GROUP by `amAggregatedDataOfAvailabilities`.`SearchEngineName`,
    `amAggregatedDataOfAvailabilities`.`Service`,
    `amAggregatedDataOfAvailabilities`.`inter`;
    
END;

