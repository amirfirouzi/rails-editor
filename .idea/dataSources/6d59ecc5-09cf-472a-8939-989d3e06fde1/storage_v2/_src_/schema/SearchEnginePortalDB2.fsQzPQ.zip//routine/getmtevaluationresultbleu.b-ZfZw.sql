create procedure getMTEvaluationResultBleu()
  BEGIN
	SELECT 
		persian_date(TestDate) as x,
        `value` as y,
		getSearchEngineFaName(translator) as serie 
    FROM 
		am_MTEvalutionResult_all
	WHERE 
		metric='Bleu'
	order by 
		TestDate, translator;
END;

