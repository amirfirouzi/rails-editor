create procedure getUserAvgQueryCount()
  BEGIN
	SELECT 
		date,
        count,
        searchEngine as serie
    FROM 
		tempUserAvgQueryCount
	ORDER BY 
		date ASC;
END;

