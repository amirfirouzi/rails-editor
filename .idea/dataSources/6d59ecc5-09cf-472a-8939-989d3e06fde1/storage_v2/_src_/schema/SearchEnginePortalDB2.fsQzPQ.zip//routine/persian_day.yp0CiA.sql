create function persian_day(indate date)
  returns varchar(10)
  begin
declare j int;
declare a int;
declare b int ;
declare c int;
declare d int;
declare yearr int;
declare f double;
declare monthh int;
declare result int;
    set j=TO_DAYS(indate) ;
		set a = j - persian_pj(475, 0, 1) ;
		set b = persian_div(a, 1029983) ;
		set c = persian_mod(a, 1029983) ;
		set d = if(c <> 1029982, persian_div(2816 * c + 1031337, 1028522), 2820) ;
    set yearr = 474 + 2820 * b + d;
		set f = (1 + j) - persian_pj(yearr, 0, 1);
		set monthh= if(f > 186, ceil((f - 6) / 30) - 1, ceil(f / 31) - 1);
        
	set result = (j - (persian_pj(yearr, monthh, 1) - 1));
    return if (CHAR_LENGTH(result) < 2, concat("0", result), concat(result, ''));
END;

