create procedure get_Concurrency_BreakPoint_Results_Video(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100))
  BEGIN
	SELECT persian_date(DATE(TestDate)) as x, 
    BreakPoint as 'نقطه شکست', 
    SearchEngineName as serie #nDCG
		FROM  SearchEnginePortalDB2.am_Nonfunctional_ConcurrencyBreakpoints
		WHERE 
				Service = 'EvaluateVideoSearchEngine' AND
                DATE(TestDate) >= DATE(startOfPeriod) AND
			    DATE(TestDate) <= DATE(endOfPeriod) 
                group by Date(TestDate), SearchEngineName, Service
		ORDER BY SearchEngineName, persian_date(DATE(TestDate));
        
END;

