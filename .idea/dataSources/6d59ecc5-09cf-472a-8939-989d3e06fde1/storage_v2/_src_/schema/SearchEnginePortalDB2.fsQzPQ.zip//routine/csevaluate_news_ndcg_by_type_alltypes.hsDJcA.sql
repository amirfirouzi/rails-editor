create procedure csEvaluate_News_nDCG_By_Type_AllTypes(IN evaluationDate varchar(100))
  BEGIN
	SELECT 
		'All' as x, #category_value as x, 
		avg(criteria_value) as 'nDCG', 
        getSearchEngineFaName(search_engine) as serie,
		evaluation_date as title
	FROM csCriteriaOverallResultsM  ccr 
	WHERE 
		service = 'news' AND
		evaluation_date = evaluationDate AND
		criteria_name = 'nDCG' AND
		category_name = ' نوع خبر'         
	group by
        search_engine,
        evaluation_date;
		
END;

