create procedure autoEvaluate_Video_nDCG_In_Period(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100),
                                                   IN isTest        varchar(64))
  BEGIN
	SELECT 
		concat(SearchEnginePortalDB2.persian_year(ResultDate), '-', SearchEnginePortalDB2.persian_month(ResultDate), '-', SearchEnginePortalDB2.persian_day(ResultDate)) as x, 
        criterionValue as nDCG, 
        retriever as serie #nDCG
		FROM  SearchEnginePortalDB2.amAccuracyResults 
		WHERE 
				service = 'EvaluateVideoSearchEngine' AND
                ResultDate >= startOfPeriod AND
			    ResultDate <= endOfPeriod AND
				criterion = 'NDCG' and 
                QueryCategory = 'All' and 
                not ((isTest = 'real') and (UUID like concat('%test%')))
		ORDER BY retriever, ResultDate;
END;

