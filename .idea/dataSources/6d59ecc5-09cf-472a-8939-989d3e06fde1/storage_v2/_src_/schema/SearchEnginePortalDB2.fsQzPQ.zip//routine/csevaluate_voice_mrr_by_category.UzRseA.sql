create procedure csEvaluate_Voice_MRR_By_Category(IN evaluationDate varchar(100))
  BEGIN
	SELECT category_value as x, criteria_value as MRR, search_engine as serie, #nDCG
		   evaluation_date as title
		FROM csCriteriaOverallResultsM  ccr 
		WHERE 
				service = 'voice' AND
				evaluation_date = evaluationDate AND
				criteria_name = 'MRR' AND
				category_name = 'query category';
END;

