create procedure csEvaluate_Text_nDCG_By_Query_Length(IN evaluationDate varchar(100))
  BEGIN
	SELECT category_value as x, criteria_value as 'nDCG', search_engine as serie,
		   evaluation_date as title
		FROM csCriteriaOverallResultsM  ccr 
		WHERE 
				service = 'text' AND
				evaluation_date = evaluationDate AND
				criteria_name = 'nDCG' AND
				category_name = 'طول پرس و جو';
END;

