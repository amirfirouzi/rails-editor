create procedure SelectResponseTimeTestStats()
  BEGIN
SELECT `tblResponseTime`.`ResponseTimeID`,
    `tblResponseTime`.`ResponseTime`,
    `tblResponseTime`.`SearchENgneName`,
    `tblResponseTime`.`TestDate`,
    `tblResponseTime`.`query`,
    `tblResponseTime`.`queryCategory`,
    `tblResponseTime`.`ServiceUnderEvaluation`,
    `tblResponseTime`.`queryType`
FROM `SearchEnginePortalDB2`.`tblResponseTime`;

END;

