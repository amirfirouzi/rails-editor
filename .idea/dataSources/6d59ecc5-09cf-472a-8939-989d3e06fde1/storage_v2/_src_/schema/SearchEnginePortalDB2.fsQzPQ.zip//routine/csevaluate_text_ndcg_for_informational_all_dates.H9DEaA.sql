create procedure csEvaluate_Text_nDCG_For_Informational_All_Dates()
  BEGIN
	SELECT 
		evaluation_date,
        format(criteria_value, 2) as 'nDCG', 
        search_engine as serie
	FROM 
		csCriteriaOverallResultsM  ccr 
	WHERE 
		service = 'text' AND
		criteria_name = 'nDCG' AND
		#category_name = 'نوع پايه' 
        #AND
        (
			category_value = 'اطلاعاتي (پرسش ضمنی)'
			OR
			category_value = 'اطلاعاتي (پرسش صریح)'
        )
	#GROUP BY 
	#	evaluation_date, search_engine
	ORDER BY
		evaluation_date asc;
END;

