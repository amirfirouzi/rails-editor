create procedure csUserGenderInfo()
  BEGIN
	SELECT DISTINCT 
					case
						when gender = 'Male' then "مرد"
						when gender = 'Female' then "زن"
					end as x, count(*) as y
		FROM csUserInfo 
		GROUP BY gender;
END;

