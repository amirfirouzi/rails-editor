create procedure get_cuncurrency_Results_Text(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100))
  BEGIN
	SELECT LPAD(ConcurrentUserCount, 2, '0') as x,  
    AVG(truncate(AvgResposneTime, 6)) as 'هم روندی', 
    SearchEngineName as serie #nDCG
		FROM  SearchEnginePortalDB2.am_nonFunctional_concurrency 
		WHERE 
				Service = 'EvaluateTextSearchEngine' AND
                DATE(TestDate) >= DATE(startOfPeriod) AND
			    DATE(TestDate) <= DATE(endOfPeriod)
                group by ConcurrentUserCount, SearchEngineName, Service
		ORDER BY SearchEngineName, ConcurrentUserCount;
END;

