create procedure nonInsertResponseTimeResult(IN `_responseTime`  float, IN `_searchENgneName` varchar(45),
                                             IN `_testDate`      date, IN `_query` varchar(45),
                                             IN `_queryCategory` varchar(45), IN `_serviceUnderEvaluation` varchar(45),
                                             IN `_queryType`     varchar(45))
  BEGIN
INSERT INTO `SearchEnginePortalDB2`.`tblResponseTime`
(
`ResponseTime`,
`SearchENgneName`,
`TestDate`,
`query`,
`queryCategory`,
`ServiceUnderEvaluation`,
`queryType`)
VALUES
(
_responseTime,
_searchENgneName,
_testDate,
_query,
_queryCategory,
_serviceUnderEvaluation,
_queryType);

END;

