create procedure noSelectProcessedConcurrencyStats()
  BEGIN
SELECT `tblProcessedConcurrencyStats`.`concurrencyID`,
    `tblProcessedConcurrencyStats`.`averageResponseTime`,
    `tblProcessedConcurrencyStats`.`concurrentUserCount`,
    `tblProcessedConcurrencyStats`.`searchEngineName`,
    `tblProcessedConcurrencyStats`.`testDate`
FROM `SearchEnginePortalDB2`.`tblProcessedConcurrencyStats`;
END;

