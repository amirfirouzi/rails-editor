create procedure getAvailDataForoneDay(IN testDate varchar(200))
  BEGIN
    
SELECT 
		`amAggregatedDataOfAvailabilities`.`SearchEngineName`,
		`amAggregatedDataOfAvailabilities`.`Service`,
        `amAggregatedDataOfAvailabilities`.`interval`,
		SUM(`amAggregatedDataOfAvailabilities`.`Hits`),
		SUM(`amAggregatedDataOfAvailabilities`.`SuccessCount`),
		SUM(`amAggregatedDataOfAvailabilities`.`FailureCount`),
		SUM(`amAggregatedDataOfAvailabilities`.`SemiFailureCount`),
		`amAggregatedDataOfAvailabilities`.`TestDate`,
		SUM(`amAggregatedDataOfAvailabilities`.`OtherErrorsCount`)
    
FROM 
		
        `SearchEnginePortalDB2`.`amAggregatedDataOfAvailabilities`
WHERE
		Service = 'EvaluateTextSearchEngine' AND
        `amAggregatedDataOfAvailabilities`.`TestDate` BETWEEN Convert(concat(date(testDate), ' 00:00:00'), datetime) AND Convert(concat(date(testDate), ' 23:59:59'), datetime)
        
GROUP BY
		`amAggregatedDataOfAvailabilities`.`SearchEngineName`,
		`amAggregatedDataOfAvailabilities`.`Service`,
        `amAggregatedDataOfAvailabilities`.`interval`;


END;

