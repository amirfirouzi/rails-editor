create procedure autoEvaluate_Image_nDCG_By_Category(IN evaluationDate varchar(100))
  BEGIN
	SELECT QueryCategory as x, criterionValue as 'nDCG', retriever as serie, #nDCG
		   ResultDate as title
		FROM  SearchEnginePortalDB2.amAccuracyResults 
		WHERE 
				service = 'EvaluateImageSearchEngine' AND
                ResultDate like concat(evaluationDate,'%') AND
				criterion = 'NDCG' ;
END;

