create procedure getImageRetrieverMAP()
  BEGIN
	select concat(SearchEnginePortalDB2.persian_year(ResultDate), '-', SearchEnginePortalDB2.persian_month(ResultDate), '-', SearchEnginePortalDB2.persian_day(ResultDate)) as x, criterionValue as y, retriever as serie from SearchEnginePortalDB2.amAccuracyResults 
	where service='EvaluateImageSearchEngine'
	and QueryCategory='All'
	and criterion='MAP';
END;

