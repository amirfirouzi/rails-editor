create procedure getUniqueUsers()
  BEGIN
	SELECT 
		date,
        users,
        searchEngine
    FROM 
		tempUniqueUsers
	ORDER BY
		date ASC;
END;

