create procedure get_aggregated_concurrency_results_news(IN searchEngineName varchar(200), IN concurrentuserCount int,
                                                         IN testDate         varchar(200))
  BEGIN

	 SELECT
		count(`am_nonFunctional_concurrency_detailed`.`ResposneTime`) as count,
		`am_nonFunctional_concurrency_detailed`.`Service`,
		`am_nonFunctional_concurrency_detailed`.`SearchEngineName`,
		AVG(`am_nonFunctional_concurrency_detailed`.`ResposneTime`) as average
	FROM 
		`SearchEnginePortalDB2`.`am_nonFunctional_concurrency_detailed`

	WHERE 
		( `am_nonFunctional_concurrency_detailed`.`Service` = 'EvaluateNewsSearchEngine' ) AND
		( `am_nonFunctional_concurrency_detailed`.`SearchEngineName` = searchEngineName ) AND
		( `am_nonFunctional_concurrency_detailed`.`ConcurrentUserCount` = concurrentuserCount ) AND
		( DATE(`am_nonFunctional_concurrency_detailed`.`TestDate`) = DATE(testDate))and
        (`am_nonFunctional_concurrency_detailed`.`ResposneTime` != 0)
        
	GROUP BY 
		`am_nonFunctional_concurrency_detailed`.`Service`,
		`am_nonFunctional_concurrency_detailed`.`SearchEngineName`,
		`am_nonFunctional_concurrency_detailed`.`ConcurrentUserCount`,
        `am_nonFunctional_concurrency_detailed`.`TestDate`
        ;

END;

