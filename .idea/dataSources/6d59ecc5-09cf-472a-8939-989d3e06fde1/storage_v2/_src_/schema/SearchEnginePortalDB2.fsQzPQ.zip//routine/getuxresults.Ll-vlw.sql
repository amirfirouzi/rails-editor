create procedure getUXResults(IN ParClass varchar(40))
  BEGIN
	SELECT 
		date,
        score,
        searchEngine as serie
	FROM 
		tempUXResults
	WHERE 
		classification = ParClass
	ORDER BY date asc, searchEngine asc;
END;

