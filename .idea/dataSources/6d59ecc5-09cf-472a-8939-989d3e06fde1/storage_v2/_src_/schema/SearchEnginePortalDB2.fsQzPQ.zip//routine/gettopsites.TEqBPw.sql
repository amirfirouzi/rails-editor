create procedure getTopSites()
  BEGIN
	SELECT 
		site as 'وبسایت', 
        rank as 'رتبه' 
	FROM tempTopSites 
    ORDER BY rank 
    LIMIT 5;
END;

