create procedure csQuerySetHasTypoInfo(IN evaluationId varchar(500))
  BEGIN
	SELECT DISTINCT 
					case 
						when has_typo = 1 then "خطادار"
						when has_typo = 0 then "صحيح"
					end as x
					, count(*) as y
		FROM csQuerySet 
		WHERE evaluation_id = evaluationId 
		GROUP BY has_typo;
END;

