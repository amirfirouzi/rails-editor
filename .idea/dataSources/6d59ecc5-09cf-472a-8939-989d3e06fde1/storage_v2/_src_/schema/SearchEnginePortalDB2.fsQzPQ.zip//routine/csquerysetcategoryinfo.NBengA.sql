create procedure csQuerySetCategoryInfo(IN evaluationId varchar(500))
  BEGIN
	SELECT DISTINCT 
					query_category as x, count(*) as y 
		FROM csQuerySet 
		WHERE evaluation_id = evaluationId 
		GROUP BY query_category;
END;

