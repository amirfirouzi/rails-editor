create procedure get_querycat_top_query(IN par_category varchar(64))
  BEGIN
	SELECT query as 'پرس و جو', category as 'دسته بندی', repeat_count as 'تعداد تکرار' FROM querycat_top_query where category=par_category
    order by repeat_count desc;
END;

