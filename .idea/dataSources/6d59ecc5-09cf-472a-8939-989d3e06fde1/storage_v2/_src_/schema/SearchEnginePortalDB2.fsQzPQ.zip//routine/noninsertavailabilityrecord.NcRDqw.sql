create procedure nonInsertAvailabilityRecord(IN AvailabilityIDParam int, IN SearchEngineNameParam varchar(50),
                                             IN TestDateParam       datetime, IN IsFailedParam tinyint(1),
                                             IN IsSemiFailedParam   tinyint(1), IN IsSuccededParam tinyint(1),
                                             IN ServiceParam        varchar(50))
  BEGIN
INSERT INTO `SearchEnginePortalDB2`.`tblAvailabilities`
(`AvailabilityID`,
`SearchEngineName`,
`TestDate`,
`IsFailed`,
`IsSemiFailed`,
`IsSucceded`,
`Service`)
VALUES
(AvailabilityIDParam ,
SearchEngineNameParam ,
TestDateParam ,
IsFailedParam ,
IsSemiFailedParam ,
IsSuccededParam,
ServiceParam );


END;

