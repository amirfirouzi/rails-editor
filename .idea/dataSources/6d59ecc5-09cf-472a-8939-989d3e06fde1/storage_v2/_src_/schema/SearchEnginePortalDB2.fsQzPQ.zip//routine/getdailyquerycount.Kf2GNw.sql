create procedure getDailyQueryCount()
  BEGIN
	SELECT 
		date as '',
        queryCount as 'تعداد پرس و جو',
        getSearchEngineFaName(searchEngine) as serie
	FROM 
		tempDailyQueryCount
	order by date asc;
END;

