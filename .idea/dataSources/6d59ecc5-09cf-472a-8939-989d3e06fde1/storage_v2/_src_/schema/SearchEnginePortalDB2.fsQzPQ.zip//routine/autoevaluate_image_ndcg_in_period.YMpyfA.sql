create procedure autoEvaluate_Image_nDCG_In_Period(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100),
                                                   IN isTest        varchar(64))
  BEGIN
	SELECT persian_date(ResultDate) as x, criterionValue as 'nDCG', retriever as serie #nDCG
		FROM  SearchEnginePortalDB2.amAccuracyResults 
		WHERE 
				service = 'EvaluateImageSearchEngine' AND
                ResultDate >= startOfPeriod AND
			    ResultDate <= endOfPeriod AND
				criterion = 'NDCG' and 
                QueryCategory = 'All' and
                not ((isTest = 'real') and (UUID like concat('%test%')))
		ORDER BY retriever, persian_date(ResultDate)
        ;
END;

