create procedure get_response_OkCount(IN par_Dir varchar(500))
  BEGIN
	select
		x,
		sum(y) as y,
		serie
	from
	(
		SELECT 
			concat(persian_year(LookupDate), '-', persian_month(LookupDate), '-', persian_day(LookupDate)) as x,
			OkCount as y,
			Source as serie
		FROM 
			tbl_SMT_DigestedTranslationLogs
		where 
			Dir = par_Dir
	) tbl
	group by
		x, serie;
END;

