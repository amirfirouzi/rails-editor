create procedure getQueryCategoryCount()
  BEGIN
	SELECT 
		category, 
        sum(`value`) as `value`
	FROM 
		tempQueryCategoryCount
	GROUP BY 
		category;
END;

