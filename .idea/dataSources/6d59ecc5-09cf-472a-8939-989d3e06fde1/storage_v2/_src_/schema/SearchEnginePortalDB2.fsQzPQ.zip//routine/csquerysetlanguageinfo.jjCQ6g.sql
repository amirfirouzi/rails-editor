create procedure csQuerySetLanguageInfo(IN evaluationId varchar(500))
  BEGIN
	SELECT DISTINCT 
					case 
						when query_lang = 'Fa' then "فارسي"
						when query_lang = 'Fa/En' then "فارسي/انگليسي"
						when query_lang = 'Ar' then "عربي"
						when query_lang = 'En' then "انگليسي"
					end as x
					, count(*) as y
		FROM csQuerySet 
		WHERE evaluation_id = evaluationId 
		GROUP BY query_lang;
END;

