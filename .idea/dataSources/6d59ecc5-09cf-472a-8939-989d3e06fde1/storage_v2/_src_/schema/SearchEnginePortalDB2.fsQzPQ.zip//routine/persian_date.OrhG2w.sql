create function persian_date(resultDate date)
  returns varchar(100)
  BEGIN

RETURN concat(SearchEnginePortalDB2.persian_year(ResultDate), '-', SearchEnginePortalDB2.persian_month(ResultDate), '-', SearchEnginePortalDB2.persian_day(ResultDate));
END;

