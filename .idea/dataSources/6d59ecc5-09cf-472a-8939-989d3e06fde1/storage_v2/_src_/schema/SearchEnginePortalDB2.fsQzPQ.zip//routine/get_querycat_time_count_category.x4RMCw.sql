create procedure get_querycat_time_count_category(IN par_category varchar(64))
  BEGIN
	SELECT LPAD(qtime, 2 ,'0') as x, qcount as y FROM querycat_time_count_category where category=par_category
    order by qtime;
END;

