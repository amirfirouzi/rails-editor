create procedure getFrequentSearchQueries()
  BEGIN
	SELECT `query`, frequency FROM tempFrequentSearchQueries;
END;

