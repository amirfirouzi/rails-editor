create procedure nonSelectAvailabilityRecords()
  BEGIN

SELECT `tblAvailabilities`.`AvailabilityID`,
    `tblAvailabilities`.`SearchEngineName`,
    `tblAvailabilities`.`TestDate`,
    `tblAvailabilities`.`IsFailed`,
    `tblAvailabilities`.`IsSemiFailed`,
    `tblAvailabilities`.`IsSucceded`,
    `tblAvailabilities`.`Service`
FROM `SearchEnginePortalDB2`.`tblAvailabilities`;

END;

