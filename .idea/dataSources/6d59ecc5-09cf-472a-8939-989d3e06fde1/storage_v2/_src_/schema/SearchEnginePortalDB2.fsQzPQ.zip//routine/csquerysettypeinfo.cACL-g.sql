create procedure csQuerySetTypeInfo(IN evaluationId varchar(500))
  BEGIN
	SELECT DISTINCT 
					case 
						when query_type = 'Informational' then "اطلاعاتي"
						when query_type = 'Navigational' then "پيمايشي"
					end as x
						, count(*) as y
		FROM csQuerySet 
		WHERE evaluation_id = evaluationId 
		GROUP BY query_type;
END;

