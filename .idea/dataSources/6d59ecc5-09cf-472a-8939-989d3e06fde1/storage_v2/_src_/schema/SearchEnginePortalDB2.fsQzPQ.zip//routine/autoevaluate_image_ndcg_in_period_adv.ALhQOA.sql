create procedure autoEvaluate_Image_nDCG_In_Period_adv(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100))
  BEGIN
	SELECT ResultDate 'date', criterionValue as 'nDCG', retriever as serie
		FROM  SearchEnginePortalDB2.amAccuracyResults 
		WHERE 
			service = 'EvaluateImageSearchEngine' AND
                ResultDate >= startOfPeriod AND
			    ResultDate <= endOfPeriod AND
				criterion = 'NDCG' and 
                QueryCategory = 'All'
		ORDER BY ResultDate;

END;

