create procedure GetMTEvaluationResults()
  BEGIN
SELECT persian_date(DATE(TestDate)) as x, 
    Bleu as 'معیار Bleu', 
    Translator as serie #nDCG
		FROM  SearchEnginePortalDB2.am_am_MTEvalutionResult
		WHERE 
                DATE(TestDate) >= DATE(startOfPeriod) AND
			    DATE(TestDate) <= DATE(endOfPeriod) 
                group by Date(TestDate), SearchEngineName, Service
		ORDER BY Translator, persian_date(DATE(TestDate));
END;

