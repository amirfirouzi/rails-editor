create procedure nonselectConcurrencyStatsforaSearchengine(IN `_count` int, IN `_engine` varchar(45),
                                                           IN `_date`  datetime, IN `_service` varchar(45))
  BEGIN
SELECT 
		`tblConcurrencyStats`.`resposneTime`,
		`tblConcurrencyStats`.`concurrentUserCount`,
		`tblConcurrencyStats`.`searchEngineName`,
		`tblConcurrencyStats`.`testDate`,
		`tblConcurrencyStats`.`ServiceUnderEvaluation`
        
FROM 	`SearchEnginePortalDB2`.`tblConcurrencyStats`

WHERE 	`tblConcurrencyStats`.`concurrentUserCount` = _count 
	AND `tblConcurrencyStats`.`searchEngineName` = _engine
	AND `tblConcurrencyStats`.`testDate` = _date
	AND `tblConcurrencyStats`.`ServiceUnderEvaluation` = _service;
END;

