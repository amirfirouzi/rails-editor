create procedure get_cuncurrency_Results_Item2_Text(IN startOfPeriod double)
  BEGIN
	SELECT ConcurrentUserCount as y, SearchEngineName as serie #nDCG
		FROM  SearchEnginePortalDB2.am_nonFunctional_concurrency 
		WHERE 
				Service = 'EvaluateTextSearchEngine' AND
                DATE(TestDate) >= DATE(startOfPeriod) AND
			    DATE(TestDate) <= DATE(endOfPeriod) 
                group by ConcurrentUserCount, SearchEngineName, Service
		ORDER BY SearchEngineName, ConcurrentUserCount;
END;

