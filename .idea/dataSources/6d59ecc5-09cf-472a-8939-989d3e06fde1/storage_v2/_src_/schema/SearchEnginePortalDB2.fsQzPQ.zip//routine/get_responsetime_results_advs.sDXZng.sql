create procedure get_ResponseTime_Results_Advs(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100),
                                               IN numberofWords int)
  BEGIN
SELECT persian_date(DATE(TestDate)) as x, 
    
    (AVG(truncate((AvarageResponseTime),6))) as 'زمان پاسخ', 
    SearchEngineName as serie #nDCG
		FROM  SearchEnginePortalDB2.am_nonFunctional_ResponseTime
		WHERE 
				Service = 'EvaluateAdvPlatform' AND
                DATE(TestDate) >= DATE(startOfPeriod) AND
			    DATE(TestDate) <= DATE(endOfPeriod) AND
                queryLength =  numberofWords
                group by Date(TestDate), SearchEngineName, Service , queryLength
		ORDER BY persian_date(DATE(TestDate)) asc;
END;

