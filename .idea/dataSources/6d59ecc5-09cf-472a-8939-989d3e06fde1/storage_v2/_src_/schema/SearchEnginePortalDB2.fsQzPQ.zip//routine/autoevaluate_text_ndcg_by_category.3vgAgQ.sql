create procedure autoEvaluate_Text_nDCG_By_Category(IN evaluationDate varchar(100))
  BEGIN
	SELECT QueryCategory as x, criterionValue as 'nDCG', retriever as serie, #nDCG
		   concat(SearchEnginePortalDB2.persian_year(ResultDate), '-', SearchEnginePortalDB2.persian_month(ResultDate), '-', SearchEnginePortalDB2.persian_day(ResultDate)) as title
		FROM  SearchEnginePortalDB2.amAccuracyResults 
		WHERE 
				service = 'EvaluateTextSearchEngine' AND
                ResultDate like concat(evaluationDate,'%') AND
				criterion = 'NDCG' ;
END;

