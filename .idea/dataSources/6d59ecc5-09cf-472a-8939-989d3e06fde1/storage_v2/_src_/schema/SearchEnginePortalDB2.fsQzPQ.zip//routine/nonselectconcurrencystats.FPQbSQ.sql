create procedure nonSelectConcurrencyStats()
  BEGIN
SELECT `tblConcurrencyStats`.`concurrencyID`,
    `tblConcurrencyStats`.`resposneTime`,
    `tblConcurrencyStats`.`concurrentUserCount`,
    `tblConcurrencyStats`.`searchEngineName`,
    `tblConcurrencyStats`.`testDate`
FROM `SearchEnginePortalDB2`.`tblConcurrencyStats`;
END;

