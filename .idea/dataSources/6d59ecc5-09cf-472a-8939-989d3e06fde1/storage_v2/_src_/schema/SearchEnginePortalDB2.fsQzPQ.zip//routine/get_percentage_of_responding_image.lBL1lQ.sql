create procedure get_Percentage_of_responding_Image(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100),
                                                    IN numberofWords int)
  BEGIN
	SELECT persian_date(DATE(TestDate)) as x, 
    truncate((avail / (avail + unavail)),6) as 'درصد پاسخگویی', 
    SearchEngineName as serie #nDCG
		FROM  
				(SELECT COUNT(*) as avail , Date(TestDate) as TestDate, SearchEngineName, Service
					FROM SearchEnginePortalDB2.am_nonFunctional_ResponseTime 
                    WHERE AvarageResponseTime != -10 AND Service = 'EvaluateImageSearchEngine' AND
                    queryLength =  2
                    group by Date(TestDate) , SearchEngineName, Service) as Avail,
				(SELECT COUNT(*) as unavail, Date(TestDate) as TestDate2, SearchEngineName as SearchEngineName2, Service as Service2
					FROM SearchEnginePortalDB2.am_nonFunctional_ResponseTime 
                    WHERE AvarageResponseTime = -10 AND
                    Service = 'EvaluateImageSearchEngine' AND queryLength =  numberofWords
                    group by Date(TestDate), SearchEngineName, Service) as unAvail  
		WHERE 
                DATE(TestDate) >= DATE(startOfPeriod) AND
			    DATE(TestDate) <= DATE(endOfPeriod) 
                group by Date(TestDate), SearchEngineName, Service
		ORDER BY persian_date(DATE(TestDate)) asc;
        
END;

