create procedure nonInsertConcurrencyStat(IN `_responseTime`     float, IN `_concurrentUserCount` int,
                                          IN `_searchEngineName` varchar(45), IN `_testDate` datetime)
  BEGIN
INSERT INTO `SearchEnginePortalDB2`.`tblConcurrencyStats`
(
`resposneTime`,
`concurrentUserCount`,
`searchEngineName`,
`testDate`)
VALUES
(
_responseTime,
_concurrentUserCount,
_searchEngineName,
_testDate);
END;

