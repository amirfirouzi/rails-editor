create procedure csEvaluate_News_nDCG_By_Time_Dependency(IN evaluationDate varchar(100))
  BEGIN
	SELECT category_value as x, criteria_value as 'nDCG', getSearchEngineFaName(search_engine) as serie,
		   evaluation_date as title
		FROM csCriteriaOverallResultsM  ccr 
		WHERE 
				service = 'news' AND
				evaluation_date = evaluationDate AND
				criteria_name = 'nDCG' AND
				category_name = 'وابستگي زماني';
END;

