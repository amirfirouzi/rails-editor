create procedure insertNewUsageStatistics(IN usage_dateTime varchar(100), IN userID int(30), IN userIP varchar(45),
                                          IN userBrowser    varchar(45), IN userOS varchar(45),
                                          IN userPlatform   varchar(45), IN methodCalled varchar(45))
  BEGIN
INSERT INTO `Meydoon`.`usage_Statistics_table`
	(
	`usage_DateTime`,
	`user_id`,
	`user_ip`,
	`user_browser`,
	`user_os`,
	`user_platform`,
	`method_called`
    )
VALUES
	(
	usage_dateTime,
	userID,
	userIP,
	userBrowser,
	userOS,
	userPlatform,
	methodCalled
    );
    SELECT LAST_INSERT_ID();
END;

