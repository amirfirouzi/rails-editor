create procedure get_last_state_table()
  BEGIN
	SELECT 
        TRUNCATE(criterionValue,2) as val, 
        0 as diff,
        retriever as searchEngine
		FROM  amAccuracyResults 
		WHERE 
				service = 'EvaluateVideoSearchEngine' AND
				criterion = 'NDCG' and 
                QueryCategory = 'All'
		ORDER BY retriever, ResultDate;

END;

