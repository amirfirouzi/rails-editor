create procedure getNonFunctionalWithJmeterResults(IN parResultType varchar(64), IN parMetric varchar(64))
  BEGIN
	select 
		persian_date(`date`) as x,
        `value` as y,
        `searchEngine` as serie
    from 
		nonFunctionalWithJmeterResults
	where
		`type` = parResultType and
        `metric` = parMetric
	order by 
		`date` desc, `searchEngine` asc;
END;

