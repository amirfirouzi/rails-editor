create procedure get_querycat_counts()
  BEGIN
	SELECT category as x, cnt as y FROM querycat_counts;
END;

