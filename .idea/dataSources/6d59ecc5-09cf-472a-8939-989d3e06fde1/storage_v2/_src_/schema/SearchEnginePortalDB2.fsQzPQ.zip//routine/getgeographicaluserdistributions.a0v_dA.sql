create procedure getGeographicalUserDistributions()
  BEGIN
	SELECT 
		province as x, 
        sum(visit) as y
    FROM tempGeographicalUserDistributions
    GROUP BY
		province
	ORDER BY
		y DESC;
END;

