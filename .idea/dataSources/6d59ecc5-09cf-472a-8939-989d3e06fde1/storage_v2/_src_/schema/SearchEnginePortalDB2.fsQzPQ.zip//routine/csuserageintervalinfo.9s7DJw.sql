create procedure csUserAgeIntervalInfo()
  BEGIN
	SELECT DISTINCT age_interval as x, count(*) as y
		FROM csUserInfo 
		GROUP BY age_interval;
END;

