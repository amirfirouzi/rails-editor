create procedure nonInsertProcessedConcurrencyStats(IN `_averageResponseTime` float, IN `_concurrentUserCount` int,
                                                    IN `_searchEngineName`    varchar(45), IN `_testDate` datetime)
  BEGIN
INSERT INTO `SearchEnginePortalDB2`.`tblProcessedConcurrencyStats`
(`averageResponseTime`,
`concurrentUserCount`,
`searchEngineName`,
`testDate`)
VALUES
(_averageResponseTime,
_concurrentUserCount,
_searchEngineName,
_testDate);
END;

