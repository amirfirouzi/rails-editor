create procedure get_final_aggregated_concurrency_results(IN searchEngineName varchar(200), IN concurrentuserCount int,
                                                          IN testDate         varchar(200))
  BEGIN

	 SELECT
		`am_nonFunctional_concurrency`.`AvgResposneTime`,
		`am_nonFunctional_concurrency`.`SearchEngineName`,
		`am_nonFunctional_concurrency`.`ConcurrentUserCount`,
        `am_nonFunctional_concurrency`.`TestDate`,
		`am_nonFunctional_concurrency`.`QueryLength`,
		`am_nonFunctional_concurrency`.`Accordance`
	FROM 
		`SearchEnginePortalDB2`.`am_nonFunctional_concurrency`

	WHERE 
		( `am_nonFunctional_concurrency`.`Service` = 'EvaluateTextSearchEngine' ) AND
		( `am_nonFunctional_concurrency`.`SearchEngineName` = searchEngineName ) AND
		( `am_nonFunctional_concurrency`.`ConcurrentUserCount` = concurrentuserCount ) AND
		( DATE(`am_nonFunctional_concurrency`.`TestDate`) = DATE(testDate));
END;

