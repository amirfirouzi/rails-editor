create function persian_mod(a double, b double)
  returns int
  BEGIN
return (a - b * floor(a / b));
END;

