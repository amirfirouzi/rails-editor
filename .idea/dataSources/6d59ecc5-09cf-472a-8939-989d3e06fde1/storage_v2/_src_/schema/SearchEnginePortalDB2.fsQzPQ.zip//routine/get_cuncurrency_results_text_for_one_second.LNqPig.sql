create procedure get_cuncurrency_Results_Text_For_One_Second(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100))
  BEGIN
SELECT 
	TestDate as x,
	LPAD(max(userCount), 2, '0') as y,
	searchEngine as serie
FROM
(
		SELECT 
			AVG(truncate(AvgResposneTime, 6)) as responseTime,
			SearchEngineName as searchEngine,
			ConcurrentUserCount as userCount,
            TestDate
		FROM  SearchEnginePortalDB2.am_nonFunctional_concurrency 
		WHERE 
			Service = 'EvaluateTextSearchEngine' #AND
			#DATE(TestDate) >= DATE(startOfPeriod) AND
			#DATE(TestDate) <= DATE(endOfPeriod)
		group by 
			ConcurrentUserCount, 
			SearchEngineName, 
			Service
		having
			AVG(truncate(AvgResposneTime, 6)) < 1
		ORDER BY 
			SearchEngineName, 
            ConcurrentUserCount
) ttt
GROUP BY 
	searchEngine;
END;

