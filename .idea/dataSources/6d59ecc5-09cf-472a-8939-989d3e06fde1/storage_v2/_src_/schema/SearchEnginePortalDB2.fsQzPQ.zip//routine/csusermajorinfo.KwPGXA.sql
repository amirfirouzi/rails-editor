create procedure csUserMajorInfo()
  BEGIN
	SELECT DISTINCT major as x, count(*) as y
		FROM csUserInfo 
		GROUP BY major;
END;

