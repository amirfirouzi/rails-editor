create procedure get_cuncurrency_Results_Image(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100))
  BEGIN
	SELECT LPAD(ConcurrentUserCount, 2, '0') as x,  
    truncate(avg(AvgResposneTime),6) as 'هم روندی', 
    SearchEngineName as serie #nDCG
		FROM  SearchEnginePortalDB2.am_nonFunctional_concurrency
		WHERE 
				Service = 'EvaluateImageSearchEngine' AND
                DATE(TestDate) >= DATE(startOfPeriod) AND
			    DATE(TestDate) <= DATE(endOfPeriod) 
                group by ConcurrentUserCount, SearchEngineName, Service
		ORDER BY SearchEngineName, ConcurrentUserCount;
END;

