create procedure GetGuestUserHomeFeed(IN pageNo int, IN pageCapacity int)
  BEGIN
		select 
			shop_table.shop_id,
			shop_table.shop_name,
			shop_table.shop_city,
			shop_table.shop_picture,
			product_table.product_id,
			product_table.product_register_date,
			product_table.product_name,
			product_table.product_description,
			product_table.product_picture,
			product_table.product_price
			
		FROM shop_table s, product_table p
		WHERE s.shop_id = p.shop_table_shop_id
        LIMIT pageNo , pageCapacity;
END;

