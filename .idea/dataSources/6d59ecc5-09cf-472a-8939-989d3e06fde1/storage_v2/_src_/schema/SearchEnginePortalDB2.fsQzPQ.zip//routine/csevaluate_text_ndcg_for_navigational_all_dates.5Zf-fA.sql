create procedure csEvaluate_Text_nDCG_For_Navigational_All_Dates()
  BEGIN
	SELECT 
		evaluation_date,
        format(criteria_value, 2) as 'nDCG', 
        search_engine as serie,
        category_value as x
	FROM 
		csCriteriaOverallResultsM  ccr 
	WHERE 
		service = 'text' AND
		criteria_name = 'nDCG' AND
		#category_name = 'نوع پايه' 
        #AND
        (
			category_value = 'پيمايشي'
        )
	ORDER BY
		evaluation_date asc;
END;

