create procedure DeleteDuplicatedRows()
  DELETE SearchEnginePortalDB2.amRetrievedResults  
FROM SearchEnginePortalDB2.amRetrievedResults
LEFT OUTER JOIN (
   SELECT MIN(id) as RowId, service, retriever, query, pageURL, UUID
   FROM SearchEnginePortalDB2.amRetrievedResults 
   GROUP BY service, retriever, query, pageURL, UUID
) as KeepRows ON
   SearchEnginePortalDB2.amRetrievedResults.id = KeepRows.RowId
WHERE
   KeepRows.RowId IS NULL;

