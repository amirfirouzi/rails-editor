create procedure nonSelectQueryCategories()
  BEGIN

SELECT distinct(QueryCategory)
FROM SearchEnginePortalDB2.amQuerySet;
 
END;

