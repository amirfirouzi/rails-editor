create procedure csEvaluate_Image_nDCG_In_Period(IN startOfPeriod varchar(100), IN endOfPeriod varchar(100))
  BEGIN
SELECT evaluation_date as x, criteria_value as 'nDCG', search_engine as serie #nDCG
		FROM csCriteriaOverallResultsM 
		WHERE 
				service = 'image' AND
				criteria_name = 'nDCG' AND
				category_name = 'All' AND
				evaluation_date >= startOfPeriod AND
			  evaluation_date <= endOfPeriod 
		ORDER BY search_engine, evaluation_date;
END;

