create procedure getNDCGValues()
  BEGIN
	SELECT 
		`type`, 
        nDCG, 
        getSearchEngineFaName(searchEngine) as serie 
	FROM 
		tempNDCGValues;
END;

