create procedure get_querycat_top_website(IN par_category varchar(64))
  BEGIN
	SELECT website as 'وبسایت', category as 'دسته بندی', visit_count as 'تعداد بازدید' FROM querycat_top_website where category=par_category
    order by visit_count desc;
END;

