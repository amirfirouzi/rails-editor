create procedure get_Availability_Results_for_Yooz_and_Parsijoo_Text()
  BEGIN
	SELECT persian_date(DATE(TestDate)) as x, 
    (sum(SuccessCount)/sum(Hits))*100 as 'دسترس پذیری', 
    SearchEngineName as serie #nDCG
		FROM  SearchEnginePortalDB2.amAggregatedDataOfAvailabilities 
		WHERE 
				Service = 'EvaluateTextSearchEngine' AND
                #DATE(TestDate) >= DATE(startOfPeriod) AND
			    #DATE(TestDate) <= DATE(endOfPeriod) AND
                (SearchEngineName = 'Parsijoo' OR SearchEngineName = 'Yooz')
        
        group by Date(TestDate), SearchEngineName, Service
		ORDER BY persian_date(DATE(TestDate)) asc;
        
END;

