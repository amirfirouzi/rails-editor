create function getSearchEngineFaName(enname varchar(45))
  returns varchar(45)
  BEGIN
	declare count int;
		declare result varchar(45);
	SET count = (SELECT count(*) FROM searchEngines WHERE name = LOWER(enname)); 
	if (count=0) then
		return enname;
    else
		SET result = (SELECT persianName FROM searchEngines WHERE name = LOWER(enname)); 
		RETURN result;
	end if;
END;

