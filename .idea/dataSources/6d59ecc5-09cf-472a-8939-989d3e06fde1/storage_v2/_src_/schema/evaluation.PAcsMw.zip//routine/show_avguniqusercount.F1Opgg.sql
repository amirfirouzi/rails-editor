create procedure Show_Avguniqusercount(IN ParStartDate  date, IN ParEndDate date, IN ParIsMobileUser tinyint,
                                       IN ParIsIntranet tinyint, IN ParServiceid smallint(6), IN ParPoviderType int(6))
  BEGIN


declare Endate1 DATE;
declare Endate2 DATE;

 set Endate1=(select max(`CurrentDate`)  FROM `ptbl_uniqusercount`  a join Services b on a.serviceid = b.id
where  b.typeId = ParPoviderType);

set Endate2=(select max(`CurrentDate`)  FROM `ptbl_uniqusercount`  a join Services b on a.serviceid = b.id
where  b.typeId = ParPoviderType and `CurrentDate`<Endate1);

select Endate1,round(avg(cnt)),namee from
(SELECT 
		CurrentDate,
		sum(`UniqUserCount`) as cnt,
        (select Providers.faname from Providers where providerid = Providers.id limit 1) as namee
	FROM `ptbl_uniqusercount` a join Services b on a.serviceid = b.id
	WHERE
		`CurrentDate`<= Endate1 and
        b.typeId = ParPoviderType
group by `CurrentDate`, providerid) as tbl1
group by  namee

	union 

select Endate2,round(avg(cnt)),namee from
(SELECT 
		CurrentDate,
		sum(`UniqUserCount`) as cnt,
        (select Providers.faname from Providers where providerid = Providers.id limit 1) as namee
	FROM `ptbl_uniqusercount` a join Services b on a.serviceid = b.id
	WHERE
		`CurrentDate`<= Endate2 and
        b.typeId = ParPoviderType
group by `CurrentDate`, providerid) as tbl2
group by  namee
;
	
	
END;

