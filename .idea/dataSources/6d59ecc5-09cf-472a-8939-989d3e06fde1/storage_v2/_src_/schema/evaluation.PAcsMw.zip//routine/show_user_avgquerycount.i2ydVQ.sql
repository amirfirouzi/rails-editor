create procedure Show_user_avgquerycount(IN ParStartDate    date, IN ParEndDate date, IN ParIsMobileUser tinyint,
                                         IN ParIsIntranet   tinyint, IN ParServiceid smallint(6),
                                         IN ParProviderType int(6))
  BEGIN
	SELECT 
		`querydate` as '',
		avg(`Avgquerycount`) as 'میانگین بازدید روزانه هر کاربر',
        (select Providers.faname from Providers where providerid = Providers.id limit 1) as faname
	FROM `ptbl_user_avgquerycount` a join Services b on a.serviceid = b.id
	WHERE
		#`IsMobileUser` = ParIsMobileUser and		#`IsIntranet` = ParIsIntranet and		#`serviceid`= ParServiceid and		`querydate` between ParStartDate and ParEndDate and
        b.typeId = ParProviderType
	GROUP BY
		`querydate`, `providerid`
	ORDER BY 
		`querydate`, `providerid`;
END;

