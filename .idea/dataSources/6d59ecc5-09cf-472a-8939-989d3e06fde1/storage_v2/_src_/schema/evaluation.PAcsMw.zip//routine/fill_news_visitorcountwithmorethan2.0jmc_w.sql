create procedure fill_News_VisitorCountWithMoreThan2(IN CurrentDate date)
  BEGIN
INSERT INTO `News_VisitorCountWithMoreThan2`
(`querydate`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,`serviceid`,
`VisitorCount`)

SELECT   CurrentDate,`IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`,count(*) 
FROM    `News_User_VisitCount`
where `querydate`=CurrentDate and visitcount>=2
group by `IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`;


END;

