create procedure Run_news()
  BEGIN
  DECLARE querydate date;
  DECLARE cur1 CURSOR FOR SELECT distinct CurrentDate FROM ptbl_uniqusercount;
  OPEN cur1;

read_loop: LOOP
    FETCH cur1 INTO querydate;
    call fill_News_User_VisitCount(querydate);
	call fill_News_VisitorCountWithMoreThan2(querydate);
   
  END LOOP;

  CLOSE cur1;


END;

