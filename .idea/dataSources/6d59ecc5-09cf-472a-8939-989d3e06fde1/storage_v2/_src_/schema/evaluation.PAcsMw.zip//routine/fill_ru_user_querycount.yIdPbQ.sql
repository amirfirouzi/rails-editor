create procedure fill_RU_User_QueryCount(IN CurrentDate date)
  BEGIN

INSERT INTO `SearchEngineDB`.`RU_User_QueryCount`
(`querydate`,
`visitorid`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,
`serviceid`,
`querycount`)
select CurrentDate,
`visitorid`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,
`serviceid`,
count(*)
from SE_Daily_Stats
where querydate=CurrentDate
group by `visitorid`,`IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`;

delete from `SearchEngineDB`.`RU_User_QueryCount`
where `querydate`= DATE_SUB(CurrentDate, INTERVAL 2 DAY) ;

END;

