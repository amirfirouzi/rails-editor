create procedure fill_ptbl_uniqusercount()
  BEGIN
INSERT INTO `SearchEngineDB`.`ptbl_uniqusercount`
(`CurrentDate`,
`IsMobileUser`,
`IsIntranet`,
`serviceid`,
`providerid`,
`UniqUserCount`)
SELECT `querydate`,
   `IsMobileUser`,
`IsIntranet`,
`serviceid`,
`providerid`,
    count(distinct `visitorid`)
FROM `SE_Daily_Stats` join Services as c on c.id=SE_Daily_Stats.serviceid
where `Isbot`=0 and ((c.typeId!=4 and `IsGoogleReferrer`=0) or c.typeId=4)
group by `querydate`,`IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`;


END;

