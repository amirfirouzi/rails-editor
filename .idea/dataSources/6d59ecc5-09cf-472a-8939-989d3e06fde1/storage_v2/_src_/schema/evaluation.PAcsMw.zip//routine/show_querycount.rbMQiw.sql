create procedure Show_querycount(IN ParStartDate  date, IN ParEndDate date, IN ParIsMobileUser tinyint,
                                 IN ParIsIntranet tinyint, IN ParServiceid smallint(6), IN ParProviderType int(6))
  BEGIN
	SELECT 
		persian_date(CurrentDate) as '',
		sum(`querycount`) as 'تعداد بازدید روزانه',
        (select Providers.faname from Providers where providerid = Providers.id limit 1) as faname
	FROM `ptbl_querycount` a join Services b on a.serviceid = b.id
	WHERE
		#`IsMobileUser` = ParIsMobileUser and
		#`IsIntranet` = ParIsIntranet and
		#`serviceid`= ParServiceid and
	 `CurrentDate` between date_sub(curdate(), INTERVAL 100 DAY) and curdate() and
        b.typeId = ParProviderType
	GROUP BY
		`CurrentDate`, `providerid`
	ORDER BY 
		`CurrentDate`, `providerid`
	;
END;

