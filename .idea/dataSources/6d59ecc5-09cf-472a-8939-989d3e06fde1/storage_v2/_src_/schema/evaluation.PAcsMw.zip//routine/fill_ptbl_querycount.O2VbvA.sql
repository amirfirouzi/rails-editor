create procedure fill_ptbl_querycount()
  BEGIN
INSERT INTO `ptbl_querycount`
(`CurrentDate`,
`IsMobileUser`,
`IsIntranet`,
`serviceid`,
`providerid`,
`querycount`)
SELECT `querydate`,
`IsMobileUser`,
`IsIntranet`,
`serviceid`,
`providerid`,
    count(*)
FROM `SE_Daily_Stats` join Services as c on c.id=SE_Daily_Stats.serviceid
where `Isbot`=0 and  ((c.typeId!=4 and `IsGoogleReferrer`=0) or c.typeId=4)
group by `querydate`,`IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`;

END;

