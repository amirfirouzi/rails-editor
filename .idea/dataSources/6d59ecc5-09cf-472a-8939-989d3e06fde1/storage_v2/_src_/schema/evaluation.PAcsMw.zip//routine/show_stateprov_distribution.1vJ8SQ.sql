create procedure Show_stateprov_distribution(IN ParStartDate    date, IN ParEndDate date, IN ParIsMobileUser tinyint,
                                             IN ParServiceid    smallint(6), IN ParProviderid smallint(6),
                                             IN ParProviderType int(6))
  BEGIN
	SELECT 
		REPLACE(`stateprov`, ' ', '') as x,
		sum(`querycount`) as y
	FROM `ptbl_stateprov_distribution` as a join Services as b on a.serviceid = b.id
	WHERE
		#`IsMobileUser` = ParIsMobileUser and		#`serviceid`= ParServiceid and		#`providerid` = ParProviderid and		`CurrentDate` between ParStartDate and ParEndDate and
        length(trim(`stateprov`))>0 and
        b.typeId = ParProviderType
	GROUP BY 
		`stateprov`;
END;

