create function persian_year(indate date)
  returns int
  begin
declare j int;
declare a int;
declare b int ;
declare c int;
declare d int;
    set j=TO_DAYS(indate) ;
		set a = j - persian_pj(475, 0, 1) ;
		set b = persian_div(a, 1029983) ;
		set c = persian_mod(a, 1029983) ;
		set d = if(c <> 1029982, persian_div(2816 * c + 1031337, 1028522), 2820) ;
        
    return 474 + 2820 * b + d;
end;

