create function Get_stateprov_FromIPNum(NumericIP bigint)
  returns varchar(50)
  BEGIN

RETURN (select stateprov from IPCity where NumericIP between ip_start and ip_end limit 1);
END;

