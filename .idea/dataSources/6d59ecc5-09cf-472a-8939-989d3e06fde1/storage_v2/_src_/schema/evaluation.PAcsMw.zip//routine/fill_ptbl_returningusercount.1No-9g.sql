create procedure fill_ptbl_ReturningUserCount(IN CurrentDate date)
  BEGIN


CALL fill_RU_User_QueryCount(CurrentDate);
CALL fill_RU_ReturningUserList(CurrentDate);
INSERT INTO `SearchEngineDB`.`ptbl_ReturningUserCount`
(`querydate`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,
`serviceid`,
`returningUserCount`)
select 
`querydate`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,
`serviceid`,
count(*)
from RU_ReturningUserList
where  `querydate`=CurrentDate
group by `querydate`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,
`serviceid`
;

delete from `SearchEngineDB`.`RU_ReturningUserList`;


END;

