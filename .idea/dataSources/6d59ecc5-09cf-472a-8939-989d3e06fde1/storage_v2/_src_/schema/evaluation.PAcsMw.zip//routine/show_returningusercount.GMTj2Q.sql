create procedure Show_ReturningUserCount(IN ParStartDate    date, IN ParEndDate date, IN ParIsMobileUser tinyint,
                                         IN ParIsIntranet   tinyint, IN ParServiceid smallint(6),
                                         IN ParPtoviderType int(6))
  BEGIN
declare Endate1 DATE;
declare Endate2 DATE;

 set Endate1=(select max(`querydate`)  FROM `ptbl_ReturningUserCount`  a join Services b on a.serviceid = b.id
where  b.typeId = ParPtoviderType);

set Endate2=(select max(`querydate`)  FROM `ptbl_ReturningUserCount`  a join Services b on a.serviceid = b.id
where  b.typeId = ParPtoviderType and `querydate`<Endate1);

select Endate1, sum(RU), ppp.faname from 
(
select a.querydate as qdate,a.providerid as pid, a.serviceid as srvid, (sum(b.UniqUserCount)/(select sum(UniqUserCount) from ptbl_uniqusercount where CurrentDate=a.querydate and providerid=a.providerid))*(sum(a.returningUserCount)/sum(b.UniqUserCount)) as RU from ptbl_ReturningUserCount as a inner join ptbl_uniqusercount as b 
on a.querydate=b.CurrentDate and a.IsIntranet=b.IsIntranet and a.IsMobileUser=b.IsMobileUser and a.serviceid=b.serviceid and a.providerid=b.providerid
group by a.serviceid,a.providerid,a.querydate
) as tt join Providers ppp on tt.pid=ppp.id
where qdate = Endate1 and
((ParPtoviderType=1 and pid in (1,2)) or (ParPtoviderType=4 and pid in (1,2,3,4,5)) or (ParPtoviderType=1005 and pid in (1,10,11,12)))
group by qdate, pid
union
select Endate2, sum(RU), ppp.faname from 
(
select a.querydate as qdate,a.providerid as pid, a.serviceid as srvid, (sum(b.UniqUserCount)/(select sum(UniqUserCount) from ptbl_uniqusercount where CurrentDate=a.querydate and providerid=a.providerid))*(sum(a.returningUserCount)/sum(b.UniqUserCount)) as RU from ptbl_ReturningUserCount as a inner join ptbl_uniqusercount as b 
on a.querydate=b.CurrentDate and a.IsIntranet=b.IsIntranet and a.IsMobileUser=b.IsMobileUser and a.serviceid=b.serviceid and a.providerid=b.providerid
group by a.serviceid,a.providerid,a.querydate
) as tt join Providers ppp on tt.pid=ppp.id
where qdate = Endate2 and
((ParPtoviderType=1 and pid in (1,2)) or (ParPtoviderType=4 and pid in (1,2,3,4,5)) or (ParPtoviderType=1005 and pid in (1,10,11,12)))
group by qdate, pid;
END;

