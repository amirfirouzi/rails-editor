create procedure Show_uniqusercount(IN ParStartDate  date, IN ParEndDate date, IN ParIsMobileUser tinyint,
                                    IN ParIsIntranet tinyint, IN ParServiceid smallint(6), IN ParPoviderType int(6))
  BEGIN
	SELECT 
		`CurrentDate`,
		sum(`UniqUserCount`),
        (select Providers.faname from Providers where providerid = Providers.id limit 1) as faname
	FROM `ptbl_uniqusercount` a join Services b on a.serviceid = b.id
	WHERE
		#`IsMobileUser` = ParIsMobileUser and		#`IsIntranet` = ParIsIntranet and		#`serviceid`= ParServiceid and		`CurrentDate` between ParStartDate and ParEndDate and
        b.typeId = ParPoviderType
	GROUP BY
		`CurrentDate`, `providerid`
	ORDER BY 
		`CurrentDate`, `providerid`
	;
END;

