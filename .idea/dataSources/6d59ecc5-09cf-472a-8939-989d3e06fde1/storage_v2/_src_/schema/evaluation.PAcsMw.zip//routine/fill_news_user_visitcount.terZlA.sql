create procedure fill_News_User_VisitCount(IN CurrentDate date)
  BEGIN
INSERT INTO `SearchEngineDB`.`News_User_VisitCount`
(`querydate`,
`visitorid`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,`serviceid`,
`visitcount`)
select CurrentDate,`visitorid`, `IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`,
count(*)
FROM `SE_Daily_Stats` join Services as c on c.id=SE_Daily_Stats.serviceid
where `Isbot`=0  and `querydate`=CurrentDate and  ((c.typeId!=4 and `IsGoogleReferrer`=0) or c.typeId=4)
group by `visitorid`,`IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`; 

delete from `SearchEngineDB`.`News_User_VisitCount` where `querydate`=DATE_SUB(CurrentDate, INTERVAL 1 DAY);

END;

