create procedure RunFillSPLight(IN ParDate date)
  BEGIN
# 	call fill_ptbl_ReturningUserCount(ParDate);
#     call fill_ptbl_stateprov_distribution();
    call fill_ptbl_uniqusercount();
    call fill_ptbl_querycount();
	  call fill_User_AvgQueryCount(ParDate);
    call fill_News_User_VisitCount(ParDate);
    call fill_News_VisitorCountWithMoreThan2(ParDate);
END;

