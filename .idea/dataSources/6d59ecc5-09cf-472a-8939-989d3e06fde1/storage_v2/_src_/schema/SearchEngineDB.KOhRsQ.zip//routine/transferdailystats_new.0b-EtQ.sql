create procedure transferDailyStats_new()
  BEGIN
SET @target_date := NULL;
    SET @log_id := NULL;
    SET @isTransfered := 0;
    SET @isProcessed := 0;
    SET @isArchived := 0;
    SET @isLogExist := NULL;
    SET @max_logged_date := NULL;
    SET autocommit = 1;
    
    SET SQL_SAFE_UPDATES = 0;
    
	SELECT @max_logged_date := date FROM TransferDailyStats_log ORDER BY date DESC LIMIT 1;
	IF (@max_logged_date!=CURDATE()) THEN
			INSERT INTO TransferDailyStats_log (`id`,`date`,`isTransfered`,`isProcessed`,`isArchived`) VALUES (NULL, DATE_ADD(@max_logged_date, INTERVAL 1 DAY), '0', '0', '0');
	END IF;
    
    SELECT @target_date := `date` 
	FROM TransferDailyStats_log 
	WHERE 
		isProcessed=0
		and 
		(date < CURDATE())
	ORDER BY date asc
	LIMIT 1;
    
    SELECT @isLogExist := COUNT(*) FROM TransferDailyStats_log WHERE date=@target_date;
    
    IF @target_date is not NULL THEN
        # log record
		IF @isLogExist=0 THEN
			INSERT INTO TransferDailyStats_log (`id`,`date`,`isTransfered`,`isProcessed`,`isArchived`) VALUES (NULL, @target_date, '0', '0', '0');
			SET @log_id := LAST_INSERT_ID();
		ELSE
			SELECT @log_id := id FROM TransferDailyStats_log WHERE `date`=@target_date LIMIT 1;
		END IF;
		
		SELECT @isTransfered:=isTransfered, @isProcessed:=isProcessed, @isArchived:=isArchived FROM TransferDailyStats_log WHERE id=@log_id;
		
		IF @isProcessed=0 THEN
			call RemoveData(@target_date);

			#get data from StatsDataGathering
			TRUNCATE TABLE SE_Daily_Stats;
			# DELETE FROM SE_Daily_Stats WHERE querydate=@target_date;
			INSERT INTO SE_Daily_Stats (visitorid, sessionid, serviceid, providerid, IPNum, visitorip, querydate, querytime, query, querywordcount, IsMobileUser, IsIntranet, Isbot, IsGoogleReferrer, referrer, UserAgent, pagenumber, resultcount, queryclass1, queryclass2) 
					SELECT visitorid, sessionid, serviceid, providerid, IPNum, visitorip, querydate, querytime, query, querywordcount, IsMobileUser, IsIntranet, Isbot, IsGoogleReferrer, referrer, UserAgent, pagenumber, resultcount, queryclass1, queryclass2 
					FROM Federated_SE_Daily_Stats
					WHERE querydate=@target_date;

			# Run all of the fill stored procedures
			CALL RunFillSP(@target_date);
			UPDATE TransferDailyStats_log SET isProcessed=1 WHERE id=@log_id;
		END IF;
	END IF;
END;

