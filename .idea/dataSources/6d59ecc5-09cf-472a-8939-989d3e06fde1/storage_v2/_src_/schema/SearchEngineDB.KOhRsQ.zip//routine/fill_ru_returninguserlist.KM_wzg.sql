create procedure fill_RU_ReturningUserList(IN CurrentDate date)
  BEGIN
INSERT INTO `SearchEngineDB`.`RU_ReturningUserList`
(`querydate`,
`visitorid`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,
`serviceid`
)

select distinct CurrentDate, t1.`visitorid`,t1.`IsIntranet`,t1.`IsMobileUser`,t1.`providerid`,t1.`serviceid` from `RU_User_QueryCount` as t1
INNER JOIN `RU_User_QueryCount` as t2
 
on t1.`visitorid`=t2.`visitorid` and t1.`IsIntranet`=t2.`IsIntranet` and t1.`IsMobileUser`=t2.`IsMobileUser` and
t1.`providerid`=t2.`providerid` and t1.`serviceid`=t2.`serviceid`
where  t2.querydate between  DATE_SUB(CurrentDate, INTERVAL 2 DAY) 
					and DATE_SUB(CurrentDate, INTERVAL 1 DAY)  and t1.querydate=CurrentDate


;
END;

