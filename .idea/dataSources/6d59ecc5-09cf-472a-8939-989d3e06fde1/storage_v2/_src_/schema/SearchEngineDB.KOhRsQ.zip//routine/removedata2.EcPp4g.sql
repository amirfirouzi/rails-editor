create procedure RemoveData2(IN ParDate date)
  BEGIN

delete from ptbl_querycount where CurrentDate=ParDate;
delete from ptbl_ReturningUserCount where querydate=ParDate;
delete from ptbl_stateprov_distribution where CurrentDate=ParDate;
delete from ptbl_uniqusercount where CurrentDate=ParDate;
delete from ptbl_user_avgquerycount where querydate=ParDate;
delete from RU_User_QueryCount where querydate=ParDate;

END;

