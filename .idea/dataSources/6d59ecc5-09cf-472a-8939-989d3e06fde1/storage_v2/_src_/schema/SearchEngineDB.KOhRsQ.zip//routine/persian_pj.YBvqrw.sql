create function persian_pj(y int, m int, d int)
  returns int
  begin
return ( 227260 +
        1029983 * persian_div((y - 474), 2820) + 
        365 * ( (persian_mod((y - 474), 2820) + 474) - 1) + 
        persian_div(682 * (persian_mod((y - 474), 2820) + 474) - 110, 2816) + 
        if(m > 6, 30 * m + 6, 31 * m)  
        + d );
END;

