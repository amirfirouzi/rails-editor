create procedure fill_ptbl_stateprov_distribution()
  BEGIN
	INSERT INTO `ptbl_stateprov_distribution`
		(
		`CurrentDate`,
		`stateprov`,
		`querycount`,
		`IsMobileUser`,
		`serviceid`,
		`providerid`
		)
	SELECT `querydate`, Get_stateprov_FromIPNum(`IPNum`),count(*) as querycount,`IsMobileUser`,`serviceid`,`providerid`    
	FROM `SE_Daily_Stats`  join Services as c on c.id=SE_Daily_Stats.serviceid
where `Isbot`=0 and ((c.typeId!=4 and `IsGoogleReferrer`=0) or c.typeId=4)
	group by Get_stateprov_FromIPNum(`IPNum`),`querydate`,`IsMobileUser`,`serviceid`,`providerid` ;
END;

