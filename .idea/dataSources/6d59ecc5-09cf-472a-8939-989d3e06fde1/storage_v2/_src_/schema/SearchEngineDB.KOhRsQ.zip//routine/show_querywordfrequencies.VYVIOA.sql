create procedure Show_QueryWordFrequencies(IN ParStartDate date, IN ParEndDate date, IN ParProviderType int(6))
  BEGIN
	SELECT
		word
      ,sum(frequency)
	FROM `Processed_QueryWordFrequencies` a join Services b on a.serviceId = b.id
    where 
		`date` between ParStartDate and ParEndDate and
        b.typeId = ParProviderType
    group by word
	order by sum(frequency);
END;

