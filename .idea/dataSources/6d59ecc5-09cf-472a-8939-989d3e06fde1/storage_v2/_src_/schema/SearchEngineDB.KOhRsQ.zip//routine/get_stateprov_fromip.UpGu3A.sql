create function Get_stateprov_FromIP(IP varchar(60))
  returns varchar(50)
  BEGIN
	DECLARE NumericIP bigint;

	set NumericIP = INET_ATON(IP);
	
	-- Return the result of the function
	RETURN (select stateprov from IPCity where NumericIP between ip_start and ip_end limit 1);


END;

