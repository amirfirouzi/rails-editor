create procedure fill_User_AvgQueryCount(IN ParDate date)
  BEGIN
INSERT INTO `SearchEngineDB`.`ptbl_user_avgquerycount`
(`querydate`,
`IsIntranet`,
`IsMobileUser`,
`providerid`,
`serviceid`,
`Avgquerycount`)
SELECT `querydate`,
`IsIntranet`,
   `IsMobileUser`,
`providerid`,
`serviceid`,
   ( (count(*)+0.0)/count(distinct `visitorid`))
FROM `SE_Daily_Stats` join Services as c on c.id=SE_Daily_Stats.serviceid
where `Isbot`=0 and ((c.typeId!=4 and `IsGoogleReferrer`=0) or c.typeId=4 ) and `querydate`=ParDate
group by `querydate`,`IsIntranet`,`IsMobileUser`,`providerid`,`serviceid`;

END;

