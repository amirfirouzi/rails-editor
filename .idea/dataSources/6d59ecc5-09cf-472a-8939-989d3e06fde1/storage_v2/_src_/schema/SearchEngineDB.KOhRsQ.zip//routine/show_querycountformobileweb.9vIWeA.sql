create procedure Show_querycountForMobileWeb(IN ParStartDate    date, IN ParEndDate date, IN ParIsMobileUser tinyint,
                                             IN ParIsIntranet   tinyint, IN ParServiceid smallint(6),
                                             IN ParProviderType int(6))
  BEGIN
	SELECT 
		CASE
			WHEN IsMobileUser = 0 THEN 'کاربر وب'
			ELSE 'کاربر موبایل'
		END AS isMobileWeb,
		sum(`querycount`)
	FROM `ptbl_querycount` as a join Services as b on a.serviceid = b.id
	WHERE
		#`IsIntranet` = ParIsIntranet and
		#`serviceid`= ParServiceid and
		`CurrentDate` between ParStartDate and ParEndDate and
        b.typeId = ParProviderType
	GROUP BY
		`IsMobileUser`;
END;

