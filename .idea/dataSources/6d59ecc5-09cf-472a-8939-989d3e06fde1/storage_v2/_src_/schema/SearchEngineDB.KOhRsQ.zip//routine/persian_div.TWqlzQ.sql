create function persian_div(a double, b double)
  returns int
  begin
return (floor(a / b));
END;

