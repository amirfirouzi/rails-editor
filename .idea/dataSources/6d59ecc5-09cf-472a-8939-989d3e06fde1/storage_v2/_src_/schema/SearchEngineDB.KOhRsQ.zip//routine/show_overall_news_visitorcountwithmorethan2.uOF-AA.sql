create procedure Show_Overall_News_VisitorCountWithMoreThan2(IN startdate date, IN enddate date)
  BEGIN
select 
a.`querydate`,a.`providerid`,sum(a.`VisitorCount`)/(sum(b.UniqUserCount)) as cnt
from News_VisitorCountWithMoreThan2 as a join ptbl_uniqusercount as b join Services as c
on a.providerid=b.providerid and a.IsIntranet=b.IsIntranet and a.IsMobileUser=b.IsMobileUser and a.serviceid=b.serviceid and a.querydate=b.CurrentDate and c.id=b.serviceid
where c.typeId=4 and a.querydate between startdate and enddate
group by a.`querydate`, a.`providerid`
;

END;

