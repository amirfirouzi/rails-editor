create function persian_date(resultDate date)
  returns varchar(100)
  BEGIN

RETURN concat(persian_year(ResultDate), '-', persian_month(ResultDate), '-', persian_day(ResultDate));
END;

