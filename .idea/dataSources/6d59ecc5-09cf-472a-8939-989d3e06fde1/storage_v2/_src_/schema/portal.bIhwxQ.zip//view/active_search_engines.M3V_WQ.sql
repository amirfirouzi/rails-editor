create view active_search_engines as
  select distinct `portal`.`search_engine_under_evaluations`.`search_engine` AS `name`
  from `portal`.`search_engine_under_evaluations`
  where (`portal`.`search_engine_under_evaluations`.`view_in_portal` = 1);

